package com.cg.BankAccount.Exception;

public class InsufficientBalanceException extends Exception {

}
