package com.cg.BankAccount.Exception;

public class InvalidAccountNumberException extends Exception {

}
