package com.cg.billinga2.ui;

import java.util.Scanner;

import com.cg.billinga2.DAO.ProductDAO;
import com.cg.billinga2.exception.ProductIdInvalidException;
import com.cg.billinga2.service.IProductService;
import com.cg.billinga2.service.ProductService;

public class ProductMain {

	public static void main(String[] args) {
		IProductService proSr=new ProductService();
       Scanner scanner=new Scanner(System.in);
       
       System.out.println("enter the product code");
       int pCode= scanner.nextInt();
       scanner.hasNextLine();
       boolean b=true;
       while(b)
       {
    	   if(pCode<=999 || pCode>=10000)
    	   {
    		   System.out.println("Enter valid code");
    		   pCode=scanner.nextInt();
    		  scanner.hasNextLine();
    	   }
    	   else
    	   {
    		   b=false;
    	   }
       }
       
       System.out.println("Enter Quantity");
       int qty= scanner.nextInt();
       scanner.hasNextLine();
       b=true;
       while(b)
       {
    	   if(qty<=0)
    	   {
    		   System.out.println("Enter quantity again");
    		   qty=scanner.nextInt();
    		   scanner.hasNextLine();
    	   }
    	   else
    	   {
    		   b=false;
    	   }
    	    }
      try {
    	  int price;
    	  price= proSr.getProductDetails(pCode).getProductPrice();
    	  int total=price*qty;
    	  System.out.println("Total:"+ total);
      }
      catch(ProductIdInvalidException e)
      {
    	  System.out.println("product is not available");
      }
       
	}
	}


