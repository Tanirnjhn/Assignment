package com.cg.billinga2.DAO;


import java.util.HashMap;

import com.cg.billinga2.bean.Product;
import com.cg.billinga2.exception.ProductIdInvalidException;
import com.cg.billinga2.util.CollectionUtil;

public class ProductDAO implements IProductDAO{
	CollectionUtil util;
	Product product;
	 HashMap<Integer,Product> hm=new HashMap<Integer,Product>();
	@Override
	public Product getProductDetails(int productCode) throws ProductIdInvalidException  {
	
		product=util.getProducts().get(productCode);
			
		if(product==null)
				throw new ProductIdInvalidException();
			
			
			return product;
		}
}
