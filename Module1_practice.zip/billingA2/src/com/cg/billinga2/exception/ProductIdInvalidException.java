package com.cg.billinga2.exception;

public class ProductIdInvalidException extends Exception {

}
