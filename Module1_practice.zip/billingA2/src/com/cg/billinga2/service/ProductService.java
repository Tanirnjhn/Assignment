package com.cg.billinga2.service;

import com.cg.billinga2.DAO.ProductDAO;
import com.cg.billinga2.bean.Product;
import com.cg.billinga2.exception.ProductIdInvalidException;

public class ProductService implements IProductService{
 ProductDAO pDAO;
	
 public ProductService() {
	super();
	this.pDAO=pDAO;
}
	@Override
	public Product getProductDetails(int productCode) throws ProductIdInvalidException {
		return pDAO.getProductDetails(productCode);
		
	}

}
