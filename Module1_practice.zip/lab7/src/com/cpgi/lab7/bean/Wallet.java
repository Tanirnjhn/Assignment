package com.cpgi.lab7.bean;

public class Wallet {
private int id;
private int balance;

public Wallet(int id, int balance)
{
	super();
	this.id= id;
	this.balance= balance;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getBalance() {
	return balance;
}

public void setBalance(int balance) {
	this.balance = balance;
}

}
