package com.cpgi.lab7.ui;

public class InsufficientBalanceOpeningException extends Exception {

}
