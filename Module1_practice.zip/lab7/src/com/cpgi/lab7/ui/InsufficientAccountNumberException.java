package com.cpgi.lab7.ui;

public class InsufficientAccountNumberException extends Exception {

}
