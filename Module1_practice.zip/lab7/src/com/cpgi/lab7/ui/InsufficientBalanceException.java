package com.cpgi.lab7.ui;

public class InsufficientBalanceException extends Exception {

}
