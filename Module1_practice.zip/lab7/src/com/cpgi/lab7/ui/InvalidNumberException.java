package com.cpgi.lab7.ui;

public class InvalidNumberException extends Exception {

}
