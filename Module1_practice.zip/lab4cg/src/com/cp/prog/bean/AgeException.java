package com.cp.prog.bean;
import java.lang.Exception;
import java.util.Scanner;

class MyException extends Exception
{
	public MyException(String s)
	{
		super (s);
	}
}

public class AgeException {

	public static void main(String[] args)
	{
	     try {
	    	 Scanner s= new Scanner(System.in);
	    	 int s1= s.nextInt();
	    	 if(s1>15)
	    	 {
	    		 throw new MyException("Age of Person");
	     }
	    	 else
	    	 {
	    		 System.out.println("Wrong");
	    	 }
	    	 
	     }
	    	 catch(MyException e)
	    	 {
	    		 System.out.println("Caught");
	    		 System.out.println(e.getMessage());
	    		 
	    	 }
	     
	    	 
	     }

	}

