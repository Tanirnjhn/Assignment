package com.cp.prog.ui;

import com.cp.prog.bean.Person;

public class Bank {

	public static void main(String[] args) {
	Person s = new Person();
	Person k = new Person();
    s.setBalance(2000);
    s.setActHol("smith");
    s.deposit(2000);
    k.setBalance(3000);
    k.setActHol("kathy");
    k.withdraw(2000);
    System.out.println("account holder is :" +s.getActHol());
    System.out.println("updated account balance is:" +s.getBalance());
    System.out.println("------------------------------------------------");
    System.out.println("account holder is:" +k.getActHol());
    System.out.println("updated account balance is:" +k.getBalance());
    
    
	}

}
