package com.cg.feedback.services;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.dao.FeedbackDao;
import com.cg.feedback.dao.IFeedbackDao;
import com.cg.feedback.exception.NoTrainerfoundException;

public class IFeedbackServices implements FeedbackServices {
    FeedbackDao repo=new IFeedbackDao();
	@Override
	public void addfeedback(Trainer trainer) {
		
		repo.addfeedback(trainer);
	}

	@Override
    public HashMap<Integer, Trainer> getTrainerList(int rate) throws NoTrainerfoundException {
		
		return repo.getTrainerList(rate);
	}

	@Override
	public boolean checkRating(int rate) {
		if(rate>0 && rate<6)
			return true;
		return false;
	}

}
