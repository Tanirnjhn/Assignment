package com.cg.feedback.services;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.exception.NoTrainerfoundException;

public interface FeedbackServices {
	 public void addfeedback(Trainer trainer);
	  public HashMap<Integer,Trainer> getTrainerList(int rate) throws NoTrainerfoundException;
	  public boolean checkRating(int rate);
}
