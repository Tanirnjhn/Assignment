package com.cg.feedback.util;

import java.time.LocalDate;
import java.util.HashMap;

import com.cg.feedback.beans.Trainer;

public class DBUtil {

	static  HashMap<Integer,Trainer>feedbackList=new HashMap<>();

public static HashMap<Integer, Trainer> getFeedbackList() {
		return feedbackList;
	}

	public static void setFeedbackList(HashMap<Integer, Trainer> feedbackList) {
		DBUtil.feedbackList = feedbackList;
	}

static {
	feedbackList.put(42,new Trainer("Smitha","Java",LocalDate.of(2000,03,13),LocalDate.of(2000,04,10),5));
	feedbackList.put(22,new Trainer("Smitha","Java",LocalDate.of(2001,01,01),LocalDate.of(2000,01,10),4));
	feedbackList.put(41,new Trainer("Smitha","Java",LocalDate.of(2001,01,13),LocalDate.of(2001,10,23),3));


}


	



}
