package com.cg.feedback.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.exception.NoTrainerfoundException;
import com.cg.feedback.services.FeedbackServices;
import com.cg.feedback.services.IFeedbackServices;

public class Main {

	public static void main(String[] args) throws NoTrainerfoundException {
		FeedbackServices fSer=new IFeedbackServices();
		Scanner scanner=new Scanner(System.in);
		Trainer train=new Trainer();
		
		while(true)
		{
			System.out.println("1.Enter the Details of Trainer");
			System.out.println("2.Display");
			
			System.out.println("Enter choice");
			int choice=scanner.nextInt();
			switch(choice)
			{
			case 1:System.out.println("Enter trainer name");
			       String tn=scanner.next();
			       train.setName(tn);
			       
			       System.out.println("Enter trainer courseName");
			       String tcn=scanner.next();
			       train.setCourseName(tcn);
			       
			       System.out.println("Enter Start Date");
			       String tsd=scanner.next();
			       DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
			     LocalDate date=LocalDate.parse(tsd, formatter);
			     train.setStartDate(date);
			     
			     System.out.println("Enter End Date");
			     String te=scanner.next();
			     DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd-MM-yyyy");
			     LocalDate date1=LocalDate.parse(te, formatter1);
			     train.setEndDate(date1);
			     
			     System.out.println("Enter Ratings");
			     int tr=scanner.nextInt();
			     boolean b= true;
			     while(b)
			     {
			    	 if(fSer.checkRating(tr)) {
			    		 b=false;
			    	 }
			    	 else
			    	 {
			    		 System.out.println("valid rating");
			    		 tr=scanner.nextInt();
			    		 
			    	 }
			     }
			    		 train.setRating(tr);
			    		 fSer.addfeedback(train);
			    		 
			  	 HashMap<Integer,Trainer> tmm=fSer.getTrainerList(tr);	 
			    	for(Map.Entry<Integer,Trainer> ter:tmm.entrySet())	
			    	{
			    		System.out.println(ter.getValue().getName());
			    		System.out.println(ter.getValue().getCourseName());
			    		System.out.println(ter.getValue().getStartDate());
			    		System.out.println(ter.getValue().getEndDate());
			    		System.out.println(ter.getValue().getRating());
			    	}
			    		 
			    	break;	 
			    		 
			    		 
			case 2: System.out.println("enter Rating");
                   int rating=scanner.nextInt();
                   boolean a= true;
                   while(a)
                   {
                	   if(fSer.checkRating(rating))
                	   {
                		   a= false;
                	   }
                	   else
                	   {
                		   System.out.println("Enter valid rating");
                	       rating=scanner.nextInt();
                	      
                	   }
                   }
                   
                   
                try {
			    	System.out.println(fSer.getTrainerList(rating));
			    	 
			     }
			     catch(NoTrainerfoundException e)
			     {
			    	 System.out.println("there is no trainer for this rating");
			     }
                break;
			     default: System.out.println("Wrong choice");
			}
		}

	}

}
