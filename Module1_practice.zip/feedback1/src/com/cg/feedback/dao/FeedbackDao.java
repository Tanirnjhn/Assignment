package com.cg.feedback.dao;

import java.util.HashMap;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.exception.NoTrainerfoundException;

public interface FeedbackDao {
  public void addfeedback(Trainer trainer);
  public HashMap<Integer,Trainer> getTrainerList(int rate) throws NoTrainerfoundException;
}
