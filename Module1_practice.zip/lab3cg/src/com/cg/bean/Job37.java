package com.cg.bean;

import java.util.Scanner;

public class Job37 {
	public static void main(String[]args)
	{
	Scanner sc = new Scanner(System.in);
    String s= sc.next();
    int str= s.length();
    if(str >= 12)
    {
    if((s.substring(str-4, str)).equals("_job"))
    
    {
    	System.out.println("True");
    	
    }
    
	else
	{
		System.out.println("False");
		
	}
    }
    else {
    	System.out.println("False");
    }
}
}