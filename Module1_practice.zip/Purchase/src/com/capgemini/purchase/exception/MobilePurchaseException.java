package com.capgemini.purchase.exception;

public class MobilePurchaseException extends Exception {

}
