package com.capgemini.purchase.service;

import java.util.List;
import java.util.Map;

import com.capgemini.purchase.bean.Mobile;
import com.capgemini.purchase.bean.PurchaseDetails;
import com.capgemini.purchase.exception.MobilePurchaseException;

public interface MobileService {
	 public Map<Integer,PurchaseDetails> insertDetails(int mobileid) throws MobilePurchaseException;
	    public List<Mobile> updateMobilesList(int mobileid)  throws MobilePurchaseException;
	    public List<Mobile> displayMobilesList()  throws MobilePurchaseException;
	    public List<Mobile> deleteMobile(int mobileId)  throws MobilePurchaseException;
	    public List<Mobile> searchMobilesList(int lowRange,int highRange)  throws MobilePurchaseException;
}
