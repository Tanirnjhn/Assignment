package com.capgemini.recharge.bean;

public enum Option {
	byName, byId;
}
