package com.cg.eis.pi;

import com.cg.eis.service.EmployeeService;

public class User {

	public static void main(String[] args) {
		EmployeeService s= new EmployeeService();
		s.getDetails();
		System.out.println(s.inschm());
		s.displayDetails();

	}

}
