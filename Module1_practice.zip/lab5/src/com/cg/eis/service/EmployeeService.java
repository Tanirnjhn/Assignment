package com.cg.eis.service;

import java.util.Scanner;


import com.cg.eis.bean.Employee;

interface EService {
    public void getDetails();
    public String inschm();
    public void displayDetails();
    
}
public class EmployeeService implements EService{
	Employee em;

	@Override
	public void getDetails() {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String dgn = sc.nextLine();
		String name= sc.nextLine();
		double salary= sc.nextDouble();
		int id = sc.nextInt();
		
		  em= new Employee( id, name, salary, dgn);
	}

	@Override
	public String inschm() {
		if(em.getSalary()<5000 && em.getDgn().equals("clerk"))
		return "No Scheme";
		else if(em.getSalary()>=5000 && em.getSalary()<20000 && em.getDgn().equals("System Association"))
		return "Scheme C";
		else if(em.getSalary()>=20000 && em.getSalary()<40000 && em.getDgn().equals("System Association"))
			return "scheme B";
		else if(em.getSalary()>=40000  && em.getDgn().equals("Manager"))
			return "Scheme A";
		else
			return null;
	}

	@Override
	public void displayDetails() {
		// TODO Auto-generated method stub
		System.out.println("Employee id is:"+ em.getId());
		System.out.println("Employee name is:"+ em.getName());
		System.out.println("Employee salary is:"+ em.getSalary());
		System.out.println("Employee designation is:"+ em.getDgn());
	}
	
}
