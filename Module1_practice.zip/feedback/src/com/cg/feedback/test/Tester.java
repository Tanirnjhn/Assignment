package com.cg.feedback.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map.Entry;

import org.junit.jupiter.api.Test;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.dao.FeedbackDao;
import com.cg.feedback.dao.IFeedbackDao;
import com.cg.feedback.exception.NoTrainerfoundException;
import com.cg.feedback.services.FeedbackServices;
import com.cg.feedback.services.IFeedbackServices;

class Tester {
  
  FeedbackServices service=new IFeedbackServices();
  
	

	@Test
	public void WhenValidDetailsArePassedFeedbackAddedSuccessfully() throws NoTrainerfoundException 
	{
		Trainer trainer=new Trainer("asd", "dfsf", LocalDate.of(2012, 02, 20),LocalDate.of(2016, 02, 20),4);
		service.addfeedback(trainer);
		assertEquals(2,service.getTrainerList(4).size());
		
	}
	
	
	@Test
	public void WhenValidRatingIsPassedShowFeedbackAddedSuccessfully() throws NoTrainerfoundException 
	{
		Trainer trainer=new Trainer("asd", "dfsf", LocalDate.of(2012, 02, 20),LocalDate.of(2016, 02, 20),1);
		service.addfeedback(trainer);
		HashMap<Integer, Trainer> hmap = service.getTrainerList(1);
		for(Entry entry: hmap.entrySet()) {
			assertEquals(trainer, entry.getValue());
		}
		
	}
	
//	@Test(expected=com.cg.feedback.exception.NoTrainerfoundException.class)
//	public void WhenInvalidRatingIsPassedShowThrowException() throws NoTrainerfoundException 
//	{
//	
//		service.getTrainerList(3);
//		
//	}
	

}
