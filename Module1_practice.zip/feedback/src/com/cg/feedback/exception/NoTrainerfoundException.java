package com.cg.feedback.exception;

public class NoTrainerfoundException extends Exception {

}
