package com.cg.feedback.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.feedback.beans.Trainer;
import com.cg.feedback.services.FeedbackServices;
import com.cg.feedback.services.IFeedbackServices;

public class Main {

	public static void main(String[] args) {
       FeedbackServices fSer=new IFeedbackServices();
       Scanner scanner=new Scanner(System.in);
       
       System.out.println("1.Enter trainer details");
       System.out.println("2.display");
       System.out.println("3.exit");
       
       System.out.println("enter the choice");
       int choice=scanner.nextInt();
       switch(choice)
       {
       case 1: System.out.println("Enter trainer name");
               String tn=scanner.next();
               System.out.println("Enter trainer courseName");
               String tcn=scanner.next();
               System.out.println("Enter trainer start date");
               String tsd=scanner.next();
               System.out.println("Enter trainer end date");
               String ted=scanner.next();
               System.out.println("Enter trainer rating");
               int tr=scanner.nextInt();
               
               Trainer train=new Trainer(tn,tcn,tsd,ted,tr);
               fSer.addfeedback(train);
               
               HashMap<Integer,Trainer> hmm=fSer.getTrainerList();
               for(Map.Entry<Integer,Trainer> mp:hmm.entrySet())
               {
            	   System.out.println(mp.getValue().getName());
            	   System.out.println(mp.getValue().getCourseName());
            	   System.out.println(mp.getValue().getStartDate());
            	   System.out.println(mp.getValue().getEndDate());
            	   System.out.println(mp.getValue().getRating());
               }
               
               break;
               
       case 2:  System.out.println("enter ratings");
                int rate=scanner.nextInt();
                
                HashMap<Integer,Trainer> hmmt=fSer.getTrainerList();
                for(Map.Entry<Integer,Trainer> mpt:hmmt.entrySet())
                {
                	if(rate== mpt.getValue().getRating())
                	{
             	   System.out.println(mpt.getValue().getName());
             	   System.out.println(mpt.getValue().getCourseName());
             	   System.out.println(mpt.getValue().getStartDate());
             	   System.out.println(mpt.getValue().getEndDate());
             	   System.out.println(mpt.getValue().getRating());
                }
               
                	else {
                		System.out.println("invalid rating");
                	     rate=scanner.nextInt();
                	     System.out.println(mpt.getValue().getName());
                   	   System.out.println(mpt.getValue().getCourseName());
                   	   System.out.println(mpt.getValue().getStartDate());
                   	   System.out.println(mpt.getValue().getEndDate());
                   	   System.out.println(mpt.getValue().getRating());
                	
                	}
                }
               
                     break; 
       
       case 3: System.exit(0);
       
       
       
       }
	}

}
