package com.cpgi.PaytmWallet.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import com.cpgi.PaytmWallet.bean.Wallet;
import com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException;
import com.cpgi.PaytmWallet.exception.InsufficientBalanceException;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;
import com.cpgi.PaytmWallet.repository.WalletRepoImp;
import com.cpgi.PaytmWallet.service.WalletServiceImp;
import com.cpgi.PaytmWallet.service.WalletServiceInterface;

class Tester {

	WalletServiceInterface service=new WalletServiceImp(new WalletRepoImp());
	//--------------------------CREATE AMOUNT----------------------------------
// when duplicate no is passed throw Exception
@Test(expected=com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException.class)
	void WhenDuplicateMobileNoIsPassedThrowException() throws  DuplicateMobileNumberException{
		service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
		service.CreateAccount("Shivi", "7830447679", new Wallet(new BigDecimal("20000.00")));
}
//When Number is passed account is created
@Test
public void WhenDuplicateNoIsPassedNotThrowException() throws  DuplicateMobileNumberException{
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
}
//-----------------SHOW BALANCE--------------------------------------------
@Test(expected=com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException.class)
public void whenInvalidNoIsPassedToShowBalanceItThrowsException() throws InvalidPhoneNumberException, DuplicateMobileNumberException {
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("2000.00")));
	service.ShowBalance("7897447679");
}
@Test
public void WhenValidMobileNoIsPassedItShowBalance()  throws InvalidPhoneNumberException, DuplicateMobileNumberException{
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
	service.ShowBalance("7830447679");
}
//---------------------------WITHDRAW AMOUNT--------------------------------
@Test(expected=com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException.class)
public void whenInvalidNoIsPassedThrowsException() throws InvalidPhoneNumberException{
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
    service.Withdraw("8978765465", new BigDecimal("2000.0"));

}
@Test
public void WhenValidMobileNoIsPassed()throws InvalidPhoneNumberException, DuplicateMobileNumberException, InsufficientBalanceException{
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
service.Withdraw("7830447679", new BigDecimal("2000.00"));


}

//-------------------DEPOSIT AMOUNT-----------------------------------------------
@Test(expected=com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException.class)
public void whenInvalidNoIsPassedItThrowsException() throws InvalidPhoneNumberException{

	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
	service.Deposit("7830447609", new BigDecimal("2000.00"));
}
@Test
public void WhenValidMobileNoIsPassedAmountIsDepositedInTheAccount()throws InvalidPhoneNumberException, DuplicateMobileNumberException, InsufficientBalanceException{
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
service.Deposit("7830447679", new BigDecimal("2000.00"));


}

//---------------------------FUND TRANSFER----------------------------------------


@Test(expected=com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException.class)
public void whenInvalidNoIsPassedToFundTransferThrowsException() throws InvalidPhoneNumberException{

	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
	service.CreateAccount("Shivi", "7500725707", new Wallet(new BigDecimal("200.00")));
	service.FundTransfer("7676897698", new BigDecimal("200.00"), "9876543210");
}
@Test
public void WhenValidMobileNoIsPassedFundTransferredInAmountSuccessfully()throws InvalidPhoneNumberException, DuplicateMobileNumberException, InsufficientBalanceException{
	service.CreateAccount("Taneesha", "7830447679", new Wallet(new BigDecimal("20000.00")));
	service.CreateAccount("Shivi", "7500725707", new Wallet(new BigDecimal("200.00")));
	service.FundTransfer("7830447679", new BigDecimal("200.00"), "7500725707");

}






}



