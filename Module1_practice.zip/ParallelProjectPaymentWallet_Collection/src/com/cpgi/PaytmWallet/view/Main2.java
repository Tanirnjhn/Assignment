package com.cpgi.PaytmWallet.view;

import java.math.BigDecimal;
import java.util.Scanner;

import javax.naming.InvalidNameException;

import com.cpgi.PaytmWallet.bean.Customer;
import com.cpgi.PaytmWallet.bean.Wallet;
import com.cpgi.PaytmWallet.repository.WalletRepoImp;
import com.cpgi.PaytmWallet.repository.WalletRepointerface;
import com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException;
import com.cpgi.PaytmWallet.exception.InsufficientBalanceException;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;
import com.cpgi.PaytmWallet.service.WalletServiceImp;
import com.cpgi.PaytmWallet.service.WalletServiceInterface;

public class Main2 {

	public static void main(String args[])throws Exception
	{/*
		WalletServiceInterface walletservice=new WalletServiceImp(new WalletRepoImp());
	
	try
	{
			System.out.println(walletservice.CreateAccount("TAni", "9876543123", new Wallet(new BigDecimal("5000"))));
			System.out.println(walletservice.CreateAccount("TAn", "9876543103", new Wallet(new BigDecimal("5078"))));
			System.out.println(walletservice.CreateAccount("TAnisha", "9876543623", new Wallet(new BigDecimal("7000"))));
			System.out.println(walletservice.ShowBalance("9876543123"));
			System.out.println(walletservice.Deposit("9876543143", new BigDecimal("5000")));
			System.out.println(walletservice.Withdraw("9876543623",new BigDecimal("5700")));
			System.out.println(walletservice.FundTransfer("9876543623",new BigDecimal("5000"),"9876543143"));
	}
	
	catch(InvalidPhoneNumberException e)
	{ 
System.out.println("InvalidPhoneNumberException");

	}
	catch(InsufficientBalanceException ee)
	{
		System.out.println("InsufficientBalanceException");
	} 
	catch( DuplicateMobileNumberException eee)
	{
		System.out.println(" DuplicateMobileNumberException");
	}*/
		
		
		WalletServiceInterface walletservice=new WalletServiceImp(new WalletRepoImp());		//Creating object of WalletService class
		Scanner scanner=new Scanner(System.in);
		
		while(true)																		//Infinite loop to show menu
		{
			System.out.println("Choose option: ");
			System.out.println("1. Create account");
			System.out.println("2. Show balance");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw ampount");
			System.out.println("5. Fund transfer");
			System.out.println("6. Exit");
			
			int choice=scanner.nextInt();
			scanner.nextLine();
			switch(choice)																//Switch case to choose option
			{
			case 1: System.out.println("Enter name: ");
					String nameC=scanner.nextLine();
					System.out.println("Enter mobile number: ");
					String mobC=scanner.nextLine();
					System.out.println("Enter amount:");
					BigDecimal amountC=scanner.nextBigDecimal();
					Wallet wallet=new Wallet(amountC);
					Customer customer=new Customer(nameC, mobC, wallet);
					customer.setName(nameC);
					customer.setMobileNo(mobC);
					
					wallet.setBalance(amountC);
					customer.setWallet(wallet);
					try
					{
						System.out.println(walletservice.CreateAccount(nameC, mobC, wallet));
						System.out.println("Account created");
						System.out.println("-----------------------------");
						break;
					}
					catch(DuplicateMobileNumberException e)
					{
						System.err.println("Mobile number already exists");
					}

			case 2: System.out.println("Enter mobile number: ");
					String mobile=scanner.nextLine();
					try
					{
						System.out.println("Current balance: "+walletservice.ShowBalance(mobile));
						System.out.println("-----------------------------");
						break;
					}
					catch(InvalidPhoneNumberException e)
					{
						System.err.println("Invalid Mobile Number");
					}
					
			case 3: System.out.println("Enter mobile number: ");
					String mobileNo=scanner.nextLine();
					System.out.println("Enter amount");
					BigDecimal deptAmpount=scanner.nextBigDecimal();
					try
					{
						System.out.println("Amount deposited, current status: "+walletservice.Deposit(mobileNo, deptAmpount));
						System.out.println("-----------------------------");
						break;
					}
					catch(InvalidPhoneNumberException e)
					{
						System.err.println("Invalid Mobile Number");
					}
			case 4: System.out.println("Enter mobile number: ");
					String withMobile=scanner.nextLine();
					System.out.println("Enter amount");
					BigDecimal withAmount=scanner.nextBigDecimal();
				
						try
						{
							System.out.println("Amount withdrawn, current status: "+walletservice.Withdraw( withMobile, withAmount));
							System.out.println("-----------------------------");
							break;
						}
						catch(InvalidPhoneNumberException e)
						{
							System.err.println("Invalid Mobile Number");
						}
						catch(InsufficientBalanceException e)
						{
							System.err.println("Insufficient Wallet Balance");
						}
						
			case 5: System.out.println("Enter source mobile number: ");
					String sourceMob=scanner.nextLine();
					System.out.println("Enter target mobile number: ");
					String targetMob=scanner.nextLine();
					System.out.println("Enter amount: ");
					BigDecimal samount=scanner.nextBigDecimal();
					try
					{
						System.out.println("Fund transfered successfully: "+walletservice.FundTransfer(sourceMob, samount, targetMob));
						System.out.println("-----------------------------");
						break;
					}
					catch(InvalidPhoneNumberException e)
					{
						System.err.println("Invalid Mobile Number");
					}
					catch(InsufficientBalanceException e)
					{
						System.err.println("Insufficient Wallet Balance");
					}
			case 6: System.exit(0);
					break;
					
			}
		}
		
		
}
}