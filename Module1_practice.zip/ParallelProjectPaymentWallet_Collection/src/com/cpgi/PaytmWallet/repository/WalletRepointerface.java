package com.cpgi.PaytmWallet.repository;

import com.cpgi.PaytmWallet.bean.Customer;

import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;


public interface WalletRepointerface {
public boolean Save(Customer c);
public Customer FindByPhone(String MobileNo)throws  InvalidPhoneNumberException;
}
