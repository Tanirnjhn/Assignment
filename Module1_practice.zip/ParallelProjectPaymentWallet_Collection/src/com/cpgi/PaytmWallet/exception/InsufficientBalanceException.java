package com.cpgi.PaytmWallet.exception;

public class InsufficientBalanceException extends Exception {

}
