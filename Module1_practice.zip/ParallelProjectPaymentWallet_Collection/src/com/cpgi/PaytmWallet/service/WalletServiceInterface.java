package com.cpgi.PaytmWallet.service;

import java.math.BigDecimal;
import java.util.List;

import javax.naming.InvalidNameException;

import com.cpgi.PaytmWallet.bean.Customer;
import com.cpgi.PaytmWallet.bean.Wallet;
import com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException;
import com.cpgi.PaytmWallet.exception.InsufficientBalanceException;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;


public interface WalletServiceInterface {
 public Customer CreateAccount(String name, String mobileno,Wallet wallet)throws  DuplicateMobileNumberException;
 public BigDecimal ShowBalance(String mobileNo) throws InvalidPhoneNumberException;
 public Customer Deposit(String mobileNo, BigDecimal amount )throws InvalidPhoneNumberException;
 public Customer Withdraw( String mobileNo, BigDecimal amount)throws InsufficientBalanceException, InvalidPhoneNumberException; 
public Customer FundTransfer (String sourceMobNo, BigDecimal amount, String target)throws InvalidPhoneNumberException,InsufficientBalanceException;

}
