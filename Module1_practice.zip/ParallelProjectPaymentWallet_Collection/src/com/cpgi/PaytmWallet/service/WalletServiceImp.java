package com.cpgi.PaytmWallet.service;

import java.math.BigDecimal;

import javax.naming.InvalidNameException;

import com.cpgi.PaytmWallet.bean.Customer;
import com.cpgi.PaytmWallet.bean.Wallet;
import com.cpgi.PaytmWallet.exception.DuplicateMobileNumberException;
import com.cpgi.PaytmWallet.exception.InsufficientBalanceException;
import com.cpgi.PaytmWallet.exception.InvalidPhoneNumberException;
import com.cpgi.PaytmWallet.repository.WalletRepoImp;

public class WalletServiceImp implements WalletServiceInterface {
   
	private WalletRepoImp repo;
	public WalletServiceImp(WalletRepoImp repo) {
		super();
		this.repo=repo;
		}

	@Override
	public Customer CreateAccount(String name, String mobileno, Wallet wallet)
			throws  DuplicateMobileNumberException {
		Customer customer = new Customer(name, mobileno, wallet);
		if(repo.Save(customer))
		{
			return customer;
		}
		else		
		throw new  DuplicateMobileNumberException() ;
		
	}
	
		@Override
	public BigDecimal ShowBalance(String mobileNo) throws InvalidPhoneNumberException  {
		
		return repo.FindByPhone(mobileNo).getWallet().getBalance();
	}

	@Override
	public Customer Deposit(String mobileNo, BigDecimal amount) throws InvalidPhoneNumberException {
		Customer customer= repo.FindByPhone(mobileNo);
		Wallet wallet = customer.getWallet();
wallet.setBalance(wallet.getBalance().add(amount));
       customer.setWallet(wallet);
		return customer;
	}

	@Override
	public Customer Withdraw( String mobileNo, BigDecimal amount)
			throws InsufficientBalanceException, InvalidPhoneNumberException {
		Customer customer= repo.FindByPhone(mobileNo);
		Wallet wallet = customer.getWallet();
		if(wallet.getBalance().compareTo(amount)==-1)
		{
			throw new  InsufficientBalanceException();
		}
		wallet.setBalance(wallet.getBalance().subtract(amount));
		customer.setWallet(wallet);
		return customer;
		
	}

	@Override
	public Customer FundTransfer( String sourceMobNo, BigDecimal amount, String target)
			throws InvalidPhoneNumberException,InsufficientBalanceException{
		Customer customer= repo.FindByPhone(sourceMobNo);
		Withdraw(sourceMobNo, amount);
		Deposit(target, amount);
		
		return customer;
		
	}


	
	

}
