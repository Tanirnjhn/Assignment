package com.capg.eleven_4;
@FunctionalInterface
public interface IProgram4 {
	public simple methodDemo();


}
