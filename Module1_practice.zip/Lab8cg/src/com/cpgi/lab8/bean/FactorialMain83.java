package com.cpgi.lab8.bean;

public class FactorialMain83 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Factorial83 b=new Factorial83();
	     Factorial83 a=new Factorial83();
	     b.start();
	     a.start();
	}

}
