package com.cpgi.lab8.bean;

import java.util.ArrayList;

public class Problem84 implements Runnable {

	ArrayList<String> productsList = new ArrayList<>();
	
	public static void main(String[] args) {
		

		Problem84 t = new Problem84();
		t.productsList.add("Apple"); t.productsList.add("Banana"); t.productsList.add("Orange"); t.productsList.add("Mango");
		Thread thread = new Thread(t);
		thread.start();
		
	}

	@Override
	public void run() {
		
		double bill=0;
		for(String s: productsList) {
			if(s.equals("Apple"))	bill+=80;
			else if(s.equals("Banana"))	bill+=50;
			else if(s.equals("Orange"))	bill+=70;
			else if(s.equals("Mango"))	bill+=75;
		}
		System.out.println("Bill : "+bill );
	}
}
