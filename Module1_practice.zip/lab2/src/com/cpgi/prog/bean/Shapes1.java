package com.cpgi.prog.bean;


abstract class S1 {
	
		 abstract void calculateArea();
		 abstract void display();

		}
		 class Rectangle extends S1{
			 void calculateArea( ) 
			 {
				 float l=20,b=30,a;
				 a= l * b;
				 System.out.println("Area of rectangle:" + a);
				 
			 }
			 void display()
			 {
				 System.out.println("drawing rectangle");
			 }
		 }
		  class Triangle extends S1{
				  void calculateArea( )
				  {
					  float l=20,b=75,a;
					  a=(l*b)/2;
					  System.out.println("Area of Triangle:"+ a);
				  }
				   void display()
				  {
					   System.out.println("drawing triangle");
				   }
			  
				   }
		 class Shapes1{
			 public static void main(String[] args)
			 {
				
				S1 b=new Rectangle();
				 b.calculateArea();
				 b.display();
				S1 c= new Triangle();
				c.calculateArea();
				c.display();
			 }
		  }
		  
		  

