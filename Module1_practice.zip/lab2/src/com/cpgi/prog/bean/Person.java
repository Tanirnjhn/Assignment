package com.cpgi.prog.bean;

import java.util.Arrays;
import java.util.Comparator;

class Employees{

private String name;
 private int age;
public String getName() {
	return name;
}
public void setName(String c) {
	
	this.name = c;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
 
 }
  class AgeComparator implements Comparator {
	   public int compare(Object emp1 , Object emp2 ) {
		int emp1Age = ((Employees) emp1).getAge(); 
		int emp2Age = ((Employees) emp2).getAge();
		
		if (emp1Age > emp2Age)
		{
			return 1;
		}
		else if(emp1Age < emp2Age)
		{
			return -1;
		}
		else {
			return 0;
		}
	   }
	   
  }
 public class Person {

	public static void main(String args[]) {
		Employees[] empl = new Employees[2];
		 empl[0] = new Employees();
		 empl[0].setName("Josh");
		 empl[0].setAge(30);
		 
		 empl[1]=new Employees();
		 empl[1].setName("ppy");
		 empl[1].setAge(40);
		 System.out.println("before Sorting");
		 
		 for(int i =0; i<empl.length ; i++)
		 System.out.println("Employee is:"+(i+1)+ "\nname :"+ empl[i].getName()+ "\n Age:"+ empl[i].getAge() );
		// TODO Auto-generated method stub
Arrays.sort(empl, new AgeComparator());
System.out.println("After Sorting");
 for(int i=0; i<empl.length; i++)
 {
	 System.out.println("Employee is:"+(i+1)+ "name :"+ empl[i].getName()+ "Age:"+ empl[i].getAge() );
 }
	}

}