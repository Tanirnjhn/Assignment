package com.cpgi.prog.bean;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

class Emp implements Comparable{
      int EmpID;
       String name;
       double salary;
       static int i;

	
public Emp()
 {
	 EmpID= i++;
	 name="Unknown";
	 salary=0.0;
 }
public Emp(String Ename, double sal)
{
	EmpID=i++;
	name=Ename;
	salary=sal;
}

@Override
public String toString() {
	return "Emp [EmpID=" + EmpID + ", name=" + name + ", salary=" + salary + "]";
}

@Override
public int compareTo(Object o) {
	if(this.salary==((Emp)o).salary)
	{

	return 0;
	}
	else if(this.salary<((Emp)o).salary)
	{
		return -1;
	}
	else
	{
		return 1;
	}
}
}
	
public class Erson {

	public static void main(String[] args) {
		Emp e1 = new Emp("Harry", 4500.0);
		Set<Emp>ts1=new TreeSet<Emp>();
		ts1.add(new Emp("Tom", 8900.0));
		ts1.add(new Emp("Sam", 6855.0));
		ts1.add(new Emp("tyre", 6855.0));
		Iterator<Emp> itr= ts1.iterator();
		 System.out.println("displaying list element in forward");
		 while(itr.hasNext())
		 {
			 Object element=itr.next();
			 System.out.println(element+"\n");
		 }
		 System.out.println();
		 
			 
	}
	}

	


