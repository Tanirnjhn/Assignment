package com.cpgi.prog.bean;

abstract class B1 {
	B1()
	{
		System.out.println("bike is running");
	}
		abstract void run();
		void changeGear()
		{
			System.out.println("gear changed");
		}
	

}
class Honda extends B1{
	void run()
	{
		System.out.println("running safely....");
	}
}
class Splender extends B1{
	void run()
	{
		System.out.println("running speed is good");
	}
}

class Bike1{
	public static void main(String args[])
	{
		B1 obj;
		obj= new Honda();
		obj.run();
		obj.changeGear();
		obj= new Splender();
		obj.run();
		
	}
}

