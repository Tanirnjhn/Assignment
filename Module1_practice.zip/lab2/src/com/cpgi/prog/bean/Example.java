package com.cpgi.prog.bean;

import java.util.Arrays;
import java.util.Comparator;

class Employe
{
private	char name;
private int Age;
	public char getName() {
	return name;
}
public void setName(char name) {
	this.name = name;
}
public int getAge() {
	return Age;
}
public void setAge(int age) {
	Age = age;
}
	
	
}
class NameComparator implements Comparator{
	public int compare(Object emp1, Object emp2)
	
	{
		char emp1Name=((Employe)emp1).getName();
		char emp2Name=((Employe)emp2).getName();
		
		if(emp1Name > emp2Name)

	{
			return 1;
			}
	
	else if(emp1Name < emp2Name)
	{
		return -1;
	}
	else
	{
		return 0;
	}
	}
	
}
public class Example {

	public static void main(String args[]) {
		// TODO Auto-generated method stub
		Employe[] empl= new Employe[2];
		empl[0] = new Employe();
		empl[0].setName('y');
		empl[0].setAge(39);
		
		empl[1] = new Employe();
		empl[1].setName('j');
        empl[1].setAge(78);
        System.out.println("before sorting");
        
        for(int i=0; i<empl.length; i++)
        {
   System.out.println("Employee is:" + (i+1)+ "\n name : " + empl[i].getName() + "\n Age:"+ empl[i].getAge());
        	}
        	Arrays.sort(empl,new NameComparator());
              System.out.println("After Sorting");
        		 for(int i=0; i<empl.length; i++)
        	        {
        	        	
 System.out.println("Employee is:" + (i+1)+ "\n name : " + empl[i].getName() + "\n Age:"+ empl[i].getAge());
        	        
        	}
        	
        	
	}}	
        	
        
        	
        	
	

