package com.cpgi.prog.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

class Student{
	int rollno;
	String name;
	 Student(int R, String n)
	 {
		 rollno= R;
		 name= n;
		 
	 }
	
	}


public class ArrayList2 {

	public static void main(String[] args) {
		
		Student s1= new Student(1, "Joy");
		Student s2= new Student(2, "Vansh");
		Student s3= new Student(3, "asha");
		 ArrayList<Student> al= new ArrayList<Student>();
		 al.add(s1);
		 al.add(s2);
		 al.add(s3);
		//System.out.println("list ");
	Iterator<Student> al1= al.iterator();
        while(al1.hasNext()) {
        	Student st=(Student)al1.next();
        	System.out.println(st.rollno + "" + st.name);
        }
	}

	
}
