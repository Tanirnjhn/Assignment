package com.cpgi.lab9.bean;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Reverse91 {

	public static void main(String[] args) {
		FileReader in = null;
		BufferedReader b = null;
		FileWriter op = null;
		BufferedWriter o = null;
		try {
			in = new FileReader("C:\\Users\\BRAJMISH\\Documents\\Brajesh Mishra\\input.txt");
			b = new BufferedReader(in);
			String s = b.readLine();
			op= new FileWriter("C:\\Users\\BRAJMISH\\Documents\\Brajesh Mishra\\output1.txt");
			o = new BufferedWriter(op);
			String s1[] = s.split("\\s");
			for (String s4 : s1) {
				StringBuilder string = new StringBuilder(s4);
				string.reverse();
				String s3 = new String(string);
				o.write(s3 + " ");
				System.out.println(s3 + " ");
			}
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		try {

			o.close();
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

	}

}
