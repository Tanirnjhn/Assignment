package com.cpgi.lab9.bean;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Even93 {

	public static void main(String[] args) {
		FileReader input=null;
	     try {
			input=new FileReader("C:\\Users\\Taneesha\\Documents\\Agrawal Taneesha\\inp.txt");
			Scanner scanner =new Scanner(input);
			while(scanner.hasNext())
			{String str=scanner.nextLine();
			String string[]=str.split(",");
			for(String s:string)
			{int i=Integer.parseInt(s);
			if(i%2==0)
				System.out.print(i+" ");
			}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
