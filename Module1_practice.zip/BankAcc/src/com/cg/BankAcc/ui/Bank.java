package com.cg.BankAcc.ui;

import java.util.LinkedList;

import com.cg.BankAcc.bean.Account;

public class Bank {
	
		LinkedList<Account> acc= new LinkedList<>();
		public String CreateAccount(int accountNo, int amount)throws InsufficientAccountNumberOpeningException{
			if(amount<500)
			{
				throw new InsufficientAccountNumberOpeningException();
				
			}
			Account accs=new Account(accountNo, amount);
			acc.add(accs);
			return "Account Created";
			
			
		}
		private Account SearchAccount(int accountNo)throws InvalidAccountNumberException{
		for(Account accs:acc)
		{
	         if(accs.getAccountNo()== accountNo)
	         {
	        	 return accs;
	        	 
	         }
		}
		throw new InvalidAccountNumberException();
			
		}
	public int WithdrawAccount(int accountNo, int amount)throws InvalidAccountNumberException,InsufficientAccountBalanceException{
		Account a= SearchAccount(accountNo);
		if(a.getAmount()>=2000)
		{
			a.setAmount(a.getAmount()-amount);
			return a.getAmount();
		}
		throw new InvalidAccountNumberException();
		
	}
	public int DepositAccount(int accountNo, int amount)throws InvalidAccountNumberException{
		Account a= SearchAccount(accountNo);
		{
			a.setAmount(a.getAmount()+amount);
			return a.getAmount();
		}
	}
	public int FundTransfer(int WitAcc, int DepAcc, int amount)throws InsufficientAccountBalanceException,InvalidAccountNumberException
	{
		Account act= SearchAccount(WitAcc);
		Account acct= SearchAccount(DepAcc);
		WithdrawAccount(WitAcc,amount);
		DepositAccount(DepAcc,amount);
		return acct.getAmount();
	}
	}

