package com.cg.BankAcc.ui;

public class InsufficientAccountNumberOpeningException extends Exception {

}
