package com.cg.BankAcc.view;

import com.cg.BankAcc.ui.Bank;
import com.cg.BankAcc.ui.InsufficientAccountBalanceException;
import com.cg.BankAcc.ui.InsufficientAccountNumberOpeningException;
import com.cg.BankAcc.ui.InvalidAccountNumberException;

public class Client {

	public static void main(String[] args) {
		Bank bnk= new Bank();
		try{
			System.out.println(bnk.CreateAccount(200,700000));
			System.out.println(bnk.CreateAccount(201, 50000));
			System.out.println("Balance:"+bnk.WithdrawAccount(200, 10000));
			System.out.println("Balance:"+ bnk.DepositAccount(201, 1500));
			System.out.println("Balance after Fund transfer is:"+ bnk.FundTransfer(200,201,10000));
		}
		catch(InsufficientAccountNumberOpeningException ex){
			System.out.println("Insufficient Account Number");
		}
		
		catch(InvalidAccountNumberException ex){
			System.out.println("Invalid Account Number");
		}
		catch(InsufficientAccountBalanceException ex){
			System.out.println("Insufficient Account Balance");
		}


	}

}
