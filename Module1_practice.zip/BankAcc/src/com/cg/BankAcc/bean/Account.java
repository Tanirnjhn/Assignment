package com.cg.BankAcc.bean;

public class Account {
	 private int accountNo;
     private int amount;
     public Account(int accntNo, int amt)
     {
    	 super();
    	 this.accountNo = accntNo;
    	 this.amount= amt;
    	 
     }
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", amount=" + amount + "]";
	}
}
