package com.cpg.prog1.ui;


import com.cpg.prog1.bean.Person24;

public class PersonMain24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person24 p=new Person24("Divya", "Bharathi",'F', "12345");
		System.out.println("First name is " + p.getFirstname());
		System.out.println("Last name is " + p.getLastname());
		System.out.println("Gender is " + p.getGender());
		System.out.println("Num is " + p.getMobileno());
	}

}
