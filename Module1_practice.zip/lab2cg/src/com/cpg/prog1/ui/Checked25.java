package com.cpg.prog1.ui;

import com.cpg.prog1.bean.Check25;
import com.cpg.prog1.bean.Gender25;
public class Checked25 {
public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		Check25 p = new Check25("Taneesha", "Agrawal", Gender25.F, 23);
		System.out.println("First Name:" +  p.getFirstName()+ "\n Last Name:"+ p.getLastName()+ "\n Age:" + p.getAge() + "\n Gender:" + p.getGender() + "\nWeight:" + p.getWeight()); 
		
	}

}
