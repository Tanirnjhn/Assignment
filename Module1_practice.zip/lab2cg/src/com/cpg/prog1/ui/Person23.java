package com.cpg.prog1.ui;

import com.cpg.prog1.bean.PersonMain23;

public class Person23 {

	public static void main(String[] args) {
		
	PersonMain23 p = new PersonMain23("Divya", "Bharati", 20, 'F', 77.5f);

    System.out.println("First Name:" +  p.getFirstName()+ "\n Last Name:"+ p.getLastName()+ "\n Age:" + p.getAge() + "\n Gender:" + p.getGender() + "\nWeight:" + p.getWeight());
	}

}
