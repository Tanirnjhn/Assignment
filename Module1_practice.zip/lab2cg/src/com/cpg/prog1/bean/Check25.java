package com.cpg.prog1.bean;


public class Check25 {
	private String firstName;
	private String lastName;
	private Gender25 G;
	private int age;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender25 getG() {
		return G;
	}
	public void setG(Gender25 g) {
		G= g;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Check25() {
		super();
	}
 public Check25(String f, String L, Gender25 t, int A)
 {
	 firstName=f;
	 lastName=L;
	 G=t;
	 age=A;
	 
	 
 }
public String getGender() {
	// TODO Auto-generated method stub
	return null;
}
public String getWeight() {
	// TODO Auto-generated method stub
	return null;
}

	}
 class checked {
public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		Check25 c = new Check25("Taneesha", "Agrawal", Gender25.F, 23);
	}

}


