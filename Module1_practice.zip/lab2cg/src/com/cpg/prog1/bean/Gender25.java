package com.cpg.prog1.bean;

public enum Gender25 {

	M,F;
}
