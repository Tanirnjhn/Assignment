package com.cpg.Recharge.view;

import com.cpg.Recharge.dao.AccountDaoImpl;
import com.cpg.Recharge.exception.InvalidMobileNumberException;
import com.cpg.Recharge.service.AccountService;
import com.cpg.Recharge.service.AccountServiceImpl;

public class main1 {

	public static void main(String[] args) throws InvalidMobileNumberException 
	{
	AccountService accs= new AccountServiceImpl(new AccountDaoImpl());
System.out.println(accs.getAccountDetails("9010210131"));
System.out.println(accs.getAccountDetails("9823920123"));
System.out.println(accs.rechargeAccount("9932012345", 500));

	}
}
