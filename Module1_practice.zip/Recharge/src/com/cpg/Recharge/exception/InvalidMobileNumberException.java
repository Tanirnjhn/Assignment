package com.cpg.Recharge.exception;

public class InvalidMobileNumberException extends Exception {

}
